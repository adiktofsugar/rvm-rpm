It is important to keep `default.gems` and `global.gems` even empty to triger automatic addition of gems to this files.
